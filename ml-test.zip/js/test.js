$("#first-choice").change(function() {
    console.log('test');

	var $dropdown = $(this);

	$.getJSON("json/data.json", function(data) {

		var key = $dropdown.val();
		var vals = [];
		var final_vals=[];
        console.log(key)

        for(let i = 0; i < key.length; i++)
        {
            switch(key[i]) {
			case 'dow':
				vals = data.dow.split(",");
				final_vals=final_vals.concat(vals);
				break;
			case 'iContract':
				vals = data.iContract.split(",");
				final_vals=final_vals.concat(vals);
				break;
			case 'iSupplier':
				vals = data.iSupplier.split(",");
				final_vals=final_vals.concat(vals);
				break;
			case 'iSource':
				vals = data.iSource.split(",");
				final_vals=final_vals.concat(vals);
				break;
			case 'iPerform':
				vals = data.iPerform.split(",");
				final_vals=final_vals.concat(vals);
				break;

			case 'iSave':
				vals = data.iSave.split(",");
				final_vals=final_vals.concat(vals);
				break;

			case 'iManage':
				vals = data.iManage.split(",");
				final_vals=final_vals.concat(vals);
				break;

			case 'TMS':
				vals = data.TMS.split(",");
				final_vals=final_vals.concat(vals);
				break;

			case 'iRequest':
				vals = data.iRequest.split(",");
				final_vals=final_vals.concat(vals);
				break;

			case 'eInvoice':
				vals = data.eInvoice.split(",");
				final_vals=final_vals.concat(vals);
				break;

			case 'base':
				vals = ['Please choose from above'];
		}
		    console.log(vals)

        }

        final_vals = final_vals.filter( function( item, index, inputArray ) {
           return inputArray.indexOf(item) == index;});

        console.log(final_vals);
		var $secondChoice = $("#second-choice");
		$secondChoice.empty();
		$.each(final_vals, function(index, value) {
			$secondChoice.append("<option>" + value + "</option>");
		});

	});
});